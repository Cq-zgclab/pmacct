from library.py.test_params import KModuleParams
import sys
testParams = KModuleParams(__file__, daemon='nfacctd', ipv4_subnet='192.168.100.')
def test(debug_core):
    pass
