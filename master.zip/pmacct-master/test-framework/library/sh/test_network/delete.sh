#!/bin/bash

# Delete framework-specific network

docker network rm pmacct_test_network
