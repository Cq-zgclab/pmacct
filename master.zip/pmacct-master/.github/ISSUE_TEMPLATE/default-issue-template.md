---
name: Default issue template
about: Please help us help you, fill in this template
title: ''
labels: ''
assignees: ''

---

**Description**
What's the issue? Did something go wrong? Would you like something new to exist?

**Version**
Provide the version in use. An output of -V is typically good, ie. `nfacctd -V`

**Appreciation**
Please consider starring this project to boost our reach on github!
